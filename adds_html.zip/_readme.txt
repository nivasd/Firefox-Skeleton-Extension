to see source:
rename file to  file.zip

to install:
drag and drop onto firefox

to use:
1. navigate to an expedia web page
2. open the side bar
  firefix menu: view | sidebar | basic sidebar name
3. click on the two parse buttons.

