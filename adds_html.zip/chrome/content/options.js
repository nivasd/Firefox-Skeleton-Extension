
// populate the list of groupings

function button_click()
{
    alert('button was clicked');
}

function on_window_load()
{
}

